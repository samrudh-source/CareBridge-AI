# CareBridge AI — Team DUALITH

**Swim with Tiny Fish Hackathon** · Samrudh N. and Khyati Agarwal  
**Tagline:** One Patient. One Journey. Connected Care.

CareBridge AI is a healthcare-information navigation prototype concept for four workflows: hospital access, medicine & blood-source discovery, clinical-trial registry discovery, and financial assistance / government scheme navigation.

## Honest implementation status

- Implemented in this starter: React UI, FastAPI endpoints, workflow selection, synthetic demo responses, explicit status labels, and a fail-closed live-mode placeholder.
- Synthetic records are fictional placeholders, not real providers or availability.
- TinyFish browser automation is **not wired up**. The adapter in `backend/app/services/tinyfish_client.py` intentionally returns `NOT VERIFIED` until the team implements and tests it against the official TinyFish SDK/API.
- The app does not diagnose, prescribe, confirm beds/appointments/medicine stock/blood units, determine trial eligibility, or guarantee scheme approval.
- Do not enter real patient-identifying or sensitive health information.

## Structure

```text
backend/   FastAPI API and synthetic fixtures
frontend/  React + Vite UI
```

## Run locally

Requirements: Python 3.10+, Node.js 18+, npm.

### Backend

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate   # Windows: .venv\\Scripts\\Activate.ps1
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

API docs: http://127.0.0.1:8000/docs  
Health check: http://127.0.0.1:8000/api/health

### Frontend (second terminal)

```bash
cd frontend
npm install
npm run dev
```

Open the local Vite URL, usually http://127.0.0.1:5173.

## API

`GET /api/health` · `GET /api/workflows` · `POST /api/search`

Example body:

```json
{"workflow":"medicine_blood","query":"O-negative blood near Bengaluru","location":"Bengaluru","mode":"demo"}
```

Use `mode: "demo"` for clearly labelled synthetic records. `mode: "live"` currently returns `NOT VERIFIED` because TinyFish is not connected.

## Next milestones

1. Implement one approved TinyFish source end-to-end using the current official SDK/API.
2. Preserve run ID, source URL, retrieval timestamp, status, result and error details.
3. Validate output schemas and add bounded retries for retryable errors only.
4. Test timeouts, blocked pages, empty results, missing fields and stale listings.
5. Review privacy and security before using real patient information.

For emergencies, contact local emergency services or go to the nearest emergency department. This prototype is not an emergency-response service or medical decision-maker.
