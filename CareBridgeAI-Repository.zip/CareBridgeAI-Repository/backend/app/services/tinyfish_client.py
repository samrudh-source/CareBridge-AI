"""Fail-closed integration boundary. TinyFish is not connected in this starter.

Implement this adapter against the official TinyFish SDK/API version used by the team.
Preserve run ID, status, source URL, retrieval time, result and error details. Validate
all extracted fields and map blocked pages, timeouts, empty results and ambiguity to
honest statuses. Do not invent SDK method names or present fixtures as live output.
"""
from fastapi import HTTPException

async def run_live_task(workflow: str, query: str, location: str) -> dict:
    raise HTTPException(status_code=501, detail={
        "status": "NOT VERIFIED",
        "message": "Live TinyFish integration is not configured. No live source was checked.",
    })
