from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from app.schemas import SearchRequest, SearchResponse
from app.services.demo_data import TITLES, DESCRIPTIONS, SAFETY_NOTICE, synthetic_results
from app.services.tinyfish_client import run_live_task

app = FastAPI(title="CareBridge AI API", description="Hackathon starter API for source-aware healthcare information discovery.", version="0.1.0")
app.add_middleware(CORSMiddleware, allow_origins=["http://127.0.0.1:5173", "http://localhost:5173"], allow_credentials=False, allow_methods=["GET", "POST"], allow_headers=["*"])

@app.get("/api/health")
def health():
    return {"status": "ok", "service": "CareBridge AI API", "live_tinyfish_enabled": False,
            "note": "Demo mode is available; live browser automation is not configured."}

@app.get("/api/workflows")
def workflows():
    return [{"id": key, "title": title, "description": DESCRIPTIONS[key]} for key, title in TITLES.items()]

@app.post("/api/search", response_model=SearchResponse)
async def search(request: SearchRequest):
    if request.mode == "live":
        await run_live_task(request.workflow, request.query, request.location)
    return SearchResponse(workflow=request.workflow, mode="demo", query=request.query, location=request.location,
        overall_status="SYNTHETIC DEMO",
        message=f"{TITLES[request.workflow]} demo response. These records are synthetic placeholders, not live source findings.",
        results=synthetic_results(request.workflow, request.query, request.location), safety_notice=SAFETY_NOTICE)
