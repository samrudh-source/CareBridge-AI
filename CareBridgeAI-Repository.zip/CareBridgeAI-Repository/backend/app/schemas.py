from typing import Literal, Optional
from pydantic import BaseModel, Field

Workflow = Literal["hospital_access", "medicine_blood", "clinical_trials", "financial_assistance"]
Mode = Literal["demo", "live"]

class SearchRequest(BaseModel):
    workflow: Workflow
    query: str = Field(min_length=3, max_length=500)
    location: str = Field(default="Bengaluru", min_length=2, max_length=120)
    mode: Mode = "demo"

class ResultItem(BaseModel):
    title: str
    summary: str
    status: Literal["SYNTHETIC DEMO", "SOURCE LISTING", "LIVE CHECK COMPLETED", "NEEDS CONFIRMATION", "NOT VERIFIED"]
    source_url: Optional[str] = None
    checked_at: Optional[str] = None
    synthetic: bool = True
    next_step: str

class SearchResponse(BaseModel):
    workflow: Workflow
    mode: Mode
    query: str
    location: str
    overall_status: str
    message: str
    results: list[ResultItem]
    safety_notice: str
